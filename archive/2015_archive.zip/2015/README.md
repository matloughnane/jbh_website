JBH website or Arranmore Challenge website
==========================================

Site can be seen in use at the [Arranmore Challenge site](http://arranmorechallenge.com)

About
---------------------

A little side project for me to try out some code.

### Plugins Used

Menu on mobile screens uses [Big Slide JS](http://ascott1.github.io/bigSlide.js/)

CSV to Table plugin uses published Google Sheets to populate table data on the Fixtures page.
[Jquery CSV to Table](http://code.google.com/p/jquerycsvtotable/)

Instagram Photos plugin called [Spectragram](http://lab.adrianquevedo.com/jquery-spectragram/) is used on the photo feed page.
